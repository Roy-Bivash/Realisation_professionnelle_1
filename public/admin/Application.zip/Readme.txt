1/ Pour lancer l'application, il est necessaire d'avoir la base de données en local.

2/ Pour lancer l'application cliquez sur Facturation.exe

